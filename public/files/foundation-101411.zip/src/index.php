<? $title = "Homepage of Foundation"; ?>
<?php include("includes/_doc_head.php"); ?>

	<div class="container">
		<div class="row">
			<div class="twelve columns">
				<h3>This is Foundation.</h3>
				<p>This is version 2.0 released on July 1, 2011</p>
				<p>Remember the docs are at <a href="http://foundation.zurb.com/">http://foundation.zurb.com</a></p>
			</div>
		</div>	
	</div><!-- container -->
<?php include("includes/_doc_foot.php");  ?>