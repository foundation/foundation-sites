$(document).ready(function() {

	/* Use this js doc for all mobile specific JS */

});